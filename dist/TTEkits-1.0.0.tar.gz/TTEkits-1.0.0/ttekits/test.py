__version__ = '0.1.0'

"""
实现你自己的轮子的功能
"""

def main():
  pass

if __name__ == '__main__':
    main()